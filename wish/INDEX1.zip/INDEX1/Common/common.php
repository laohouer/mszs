<?php
function p($array){
	dump($array, 1, '<pre>', 0); 
}
?>